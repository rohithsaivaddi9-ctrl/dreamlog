import test from 'node:test';
import assert from 'node:assert/strict';
import { openDb } from '../server/src/db';
import { countSleep, deleteSleep, listCaffeine, addCaffeine, listSleep, upsertSleep, upsertStudy } from '../server/src/repo';
import { seedDatabase } from '../server/src/seed';
import { SEED_DAYS } from '../server/src/seedData';
import { getAnalytics, getCaffeineStatus, getReport } from '../server/src/services';
import { sleepDurationHours } from '../shared/time';
import { validateSleepInput, validateStudyInput } from '../shared/validation';

const TODAY = '2026-11-15';

function seeded() {
  const db = openDb(':memory:');
  seedDatabase(db, TODAY);
  return db;
}

test('seed data matches the brief: 21 days, 5-9 h sleep, 2-8 h study, focus 1-5', () => {
  assert.equal(SEED_DAYS.length, 21);
  for (const d of SEED_DAYS) {
    const h = sleepDurationHours(d.bedtime, d.wakeTime);
    assert.ok(h >= 5 && h <= 9, `sleep ${h}`);
    assert.ok(d.hoursStudied >= 2 && d.hoursStudied <= 8, `study ${d.hoursStudied}`);
    assert.ok(d.focus >= 1 && d.focus <= 5);
    assert.ok(d.quality >= 1 && d.quality <= 5);
  }
  const db = seeded();
  assert.equal(countSleep(db), 21);
});

test('before the demo: 21 days give r ≈ +0.77 (Strong Positive)', () => {
  const a = getAnalytics(seeded(), TODAY);
  assert.equal(a.current.n, 21);
  assert.equal(a.current.r!.toFixed(2), '0.77');
  assert.equal(a.current.label, 'Strong Positive Correlation');
  assert.equal(a.current.notice, null);
  assert.equal(a.latest!.date, '2026-11-14'); // yesterday; today is free for the demo night
  assert.equal(a.debt.target, 8);
  assert.ok(a.insights.some((i) => i.id === 'rested-vs-other' && /higher study focus/.test(i.text)));
});

test('demo night from the brief raises r to +0.78 and becomes the highlighted point', () => {
  const db = seeded();
  // Last night: 11:30 PM -> 7:30 AM, 4 stars
  const sleep = validateSleepInput({ date: TODAY, bedtime: '23:30', wakeTime: '07:30', quality: 4 });
  assert.ok(sleep.ok);
  assert.equal(sleep.value.durationHours, 8);
  upsertSleep(db, sleep.value);
  // Today: 4.5 h Algorithms, focus 5
  const study = validateStudyInput({ date: TODAY, hoursStudied: 4.5, subjects: ['Algorithms'], focus: 5, score: null });
  assert.ok(study.ok);
  upsertStudy(db, study.value);

  const a = getAnalytics(db, TODAY);
  assert.equal(a.current.n, 22);
  assert.equal(a.current.r!.toFixed(2), '0.78');
  assert.equal(a.current.label, 'Strong Positive Correlation');
  assert.equal(a.previous!.r!.toFixed(2), '0.77');
  assert.ok(a.current.r! > a.previous!.r!);
  assert.equal(a.latest!.date, TODAY);
  assert.equal(a.latest!.sleepHours, 8);
  assert.equal(a.latest!.focus, 5);
});

test('logging the same day twice updates it instead of duplicating', () => {
  const db = seeded();
  const first = validateSleepInput({ date: TODAY, bedtime: '23:30', wakeTime: '07:30', quality: 4 });
  const second = validateSleepInput({ date: TODAY, bedtime: '00:30', wakeTime: '07:30', quality: 2 });
  assert.ok(first.ok && second.ok);
  upsertSleep(db, first.value);
  upsertSleep(db, second.value);
  assert.equal(listSleep(db).filter((s) => s.date === TODAY).length, 1);
  assert.equal(listSleep(db).find((s) => s.date === TODAY)!.durationHours, 7);
  assert.equal(deleteSleep(db, TODAY), true);
  assert.equal(deleteSleep(db, TODAY), false);
});

test('empty and tiny datasets show the confidence notice', () => {
  const empty = getAnalytics(openDb(':memory:'), TODAY);
  assert.equal(empty.current.n, 0);
  assert.equal(empty.current.r, null);
  assert.equal(empty.latest, null);
  assert.equal(empty.current.notice, 'Needs at least 7 days of logs for statistical confidence');

  const db = openDb(':memory:');
  for (let i = 0; i < 4; i++) {
    const date = `2026-11-0${i + 1}`;
    upsertSleep(db, { date, bedtime: '23:00', wakeTime: '07:00', quality: 3, durationHours: 8 - i });
    upsertStudy(db, { date, hoursStudied: 3, subjects: ['Math'], focus: 5 - i, score: null });
  }
  const small = getAnalytics(db, TODAY);
  assert.equal(small.current.n, 4);
  assert.equal(small.current.sufficient, false);
  assert.ok(small.current.notice);
});

test('sleep debt is computed from the last 7 nights against the 8 hour target', () => {
  const a = getAnalytics(seeded(), TODAY);
  assert.equal(a.debt.nights.length, 7);
  assert.equal(a.debt.endDate, '2026-11-14');
  const manual = a.debt.nights.reduce((s, n) => s + Math.max(0, 8 - (n.hours ?? 8)), 0);
  assert.ok(Math.abs(manual - a.debt.shortfall) < 0.11);
});

test('caffeine status and report', () => {
  const db = seeded();
  const yesterday = '2026-11-14';
  const status = getCaffeineStatus(db, yesterday, '23:30');
  assert.equal(status.doses.length, 3);
  assert.ok(status.mgAtBedtime > 0);
  assert.equal(getCaffeineStatus(db, TODAY, '23:30').level, 'none');
  addCaffeine(db, { date: TODAY, time: '09:00', drink: 'Coffee', mg: 100 });
  assert.equal(listCaffeine(db, TODAY).length, 1);

  const report = getReport(db, TODAY);
  assert.equal(report.daysLogged, 21);
  assert.ok(report.examScores.length >= 3);
  assert.ok(report.examCorrelation && report.examCorrelation.n === report.examScores.length);
});
