import { useCallback, useEffect, useState, type FormEvent } from 'react';
import type { AnalyticsResponse, CaffeineLog } from '../../../shared/types';
import { DRINK_PRESETS } from '../../../shared/caffeine';
import { formatClock12, sleepDurationHours } from '../../../shared/time';
import { formatR } from '../../../shared/stats';
import { api } from '../lib/api';
import {
  Card,
  ErrorNote,
  Field,
  FocusPicker,
  StarRating,
  SuccessNote,
  focusText,
  ghostButton,
  inputClass,
  primaryButton,
} from '../components/ui';

type Reload = () => Promise<AnalyticsResponse | null>;

interface Props {
  today: string;
  reload: Reload;
  go: (route: 'dashboard') => void;
}

const SUBJECT_SUGGESTIONS = ['Algorithms', 'Calculus', 'Physics', 'Databases', 'Operating Systems', 'Literature'];

function describeChange(after: AnalyticsResponse | null): string {
  if (!after) return '';
  const { current, previous } = after;
  const was = previous && previous.r !== null ? ` (was ${formatR(previous.r)} before the newest day)` : '';
  return ` Correlation is now r = ${formatR(current.r)} across ${current.n} days${was}.`;
}

export function LogPage({ today, reload, go }: Props) {
  const [demoBusy, setDemoBusy] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);

  async function runDemo() {
    setDemoBusy(true);
    setDemoError(null);
    try {
      await api.saveSleep({ date: today, bedtime: '23:30', wakeTime: '07:30', quality: 4 });
      await api.saveStudy({ date: today, hoursStudied: 4.5, subjects: ['Algorithms'], focus: 5, score: null });
      await reload();
      go('dashboard');
    } catch (e) {
      setDemoError(e instanceof Error ? e.message : 'Demo failed');
    } finally {
      setDemoBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <Card
        title="Try the demo night"
        subtitle="Logs 11:30 PM to 7:30 AM (8.0 h, 4 stars) and 4.5 h of Algorithms at focus 5/5, then opens the dashboard so you can watch the correlation and scatter plot update."
        action={
          <button className={primaryButton} onClick={() => void runDemo()} disabled={demoBusy}>
            {demoBusy ? 'Logging…' : 'Log demo night'}
          </button>
        }
      >
        {demoError ? <ErrorNote>{demoError}</ErrorNote> : <p className="text-sm text-slate-400">Logs go to today ({today}). Running it again just overwrites today's entry.</p>}
      </Card>
      <div className="grid gap-5 lg:grid-cols-2">
        <SleepForm today={today} reload={reload} />
        <StudyForm today={today} reload={reload} />
      </div>
      <CaffeineLogger today={today} />
    </div>
  );
}

function SleepForm({ today, reload }: { today: string; reload: Reload }) {
  const [date, setDate] = useState(today);
  const [bedtime, setBedtime] = useState('23:30');
  const [wakeTime, setWakeTime] = useState('07:30');
  const [quality, setQuality] = useState(4);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);

  let duration: number | null = null;
  try {
    duration = sleepDurationHours(bedtime, wakeTime);
  } catch {
    duration = null;
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSaved(null);
    try {
      await api.saveSleep({ date, bedtime, wakeTime, quality });
      const after = await reload();
      setSaved(`Saved ${duration} hours of sleep for ${date}.${describeChange(after)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card title="Nightly sleep logger" subtitle="The date is the morning you woke up.">
      <form onSubmit={(e) => void submit(e)} className="space-y-4">
        <Field label="Wake-up date">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} required />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Bedtime">
            <input type="time" value={bedtime} onChange={(e) => setBedtime(e.target.value)} className={inputClass} required />
          </Field>
          <Field label="Wake time">
            <input type="time" value={wakeTime} onChange={(e) => setWakeTime(e.target.value)} className={inputClass} required />
          </Field>
        </div>
        <p className="rounded-lg bg-slate-900/60 px-3 py-2 text-sm text-slate-300">
          {duration === null || duration === 0 ? (
            'Bedtime and wake time must be different.'
          ) : (
            <>
              Total sleep: <strong className="text-amber-300">{duration.toFixed(1)} hours</strong> ({formatClock12(bedtime)} → {formatClock12(wakeTime)}
              {bedtime > wakeTime ? ', crossing midnight' : ''})
            </>
          )}
        </p>
        <Field label="Sleep quality">
          <StarRating value={quality} onChange={setQuality} label="Sleep quality" />
        </Field>
        {error && <ErrorNote>{error}</ErrorNote>}
        {saved && <SuccessNote>{saved}</SuccessNote>}
        <button type="submit" className={primaryButton} disabled={busy || !duration}>
          {busy ? 'Saving…' : 'Save sleep'}
        </button>
      </form>
    </Card>
  );
}

function StudyForm({ today, reload }: { today: string; reload: Reload }) {
  const [date, setDate] = useState(today);
  const [hours, setHours] = useState('4.5');
  const [subjects, setSubjects] = useState('Algorithms');
  const [focus, setFocus] = useState(5);
  const [score, setScore] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);

  const chosen = subjects.split(',').map((s) => s.trim()).filter(Boolean);
  function toggle(name: string) {
    setSubjects(chosen.includes(name) ? chosen.filter((s) => s !== name).join(', ') : [...chosen, name].join(', '));
  }

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setSaved(null);
    try {
      await api.saveStudy({
        date,
        hoursStudied: Number(hours),
        subjects: chosen,
        focus,
        score: score.trim() === '' ? null : Number(score),
      });
      const after = await reload();
      setSaved(`Saved ${hours} h of study for ${date} (${focusText(focus)}).${describeChange(after)}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card title="Study session tracker" subtitle="Log the day you studied, and how focused you were.">
      <form onSubmit={(e) => void submit(e)} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Study date">
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} required />
          </Field>
          <Field label="Hours studied">
            <input type="number" min={0} max={16} step={0.25} value={hours} onChange={(e) => setHours(e.target.value)} className={inputClass} required />
          </Field>
        </div>
        <Field label="Subjects" hint="Separate with commas, or tap a suggestion.">
          <input value={subjects} onChange={(e) => setSubjects(e.target.value)} className={inputClass} placeholder="Algorithms, Calculus" />
        </Field>
        <div className="flex flex-wrap gap-2">
          {SUBJECT_SUGGESTIONS.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => toggle(s)}
              className={`rounded-full border px-3 py-1 text-xs ${chosen.includes(s) ? 'border-sky-400 bg-sky-400/20 text-sky-100' : 'border-slate-600 text-slate-300 hover:border-slate-400'}`}
            >
              {s}
            </button>
          ))}
        </div>
        <Field label="Focus rating">
          <FocusPicker value={focus} onChange={setFocus} />
        </Field>
        <Field label="Quiz or exam score (optional)" hint="0 to 100. Used in the wellness report.">
          <input type="number" min={0} max={100} step={1} value={score} onChange={(e) => setScore(e.target.value)} className={`${inputClass} w-32`} />
        </Field>
        {error && <ErrorNote>{error}</ErrorNote>}
        {saved && <SuccessNote>{saved}</SuccessNote>}
        <button type="submit" className={primaryButton} disabled={busy}>
          {busy ? 'Saving…' : 'Save study log'}
        </button>
      </form>
    </Card>
  );
}

function CaffeineLogger({ today }: { today: string }) {
  const [date, setDate] = useState(today);
  const [drink, setDrink] = useState(DRINK_PRESETS[0].drink);
  const [mg, setMg] = useState(String(DRINK_PRESETS[0].mg));
  const [time, setTime] = useState('09:00');
  const [logs, setLogs] = useState<CaffeineLog[]>([]);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setLogs(await api.listCaffeine(date));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load caffeine log');
    }
  }, [date]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  function pick(name: string) {
    setDrink(name);
    const preset = DRINK_PRESETS.find((p) => p.drink === name);
    if (preset) setMg(String(preset.mg));
  }

  async function add(e: FormEvent) {
    e.preventDefault();
    try {
      await api.addCaffeine({ date, time, drink, mg: Number(mg) });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save');
    }
  }

  async function remove(id: number) {
    try {
      await api.deleteCaffeine(id);
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete');
    }
  }

  return (
    <Card title="Caffeine intake logger" subtitle="Amounts are typical averages. Edit the mg if you know better. The dashboard shows how much is still active at bedtime.">
      <div className="grid gap-5 lg:grid-cols-2">
        <form onSubmit={(e) => void add(e)} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Day">
              <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={inputClass} required />
            </Field>
            <Field label="Time">
              <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className={inputClass} required />
            </Field>
          </div>
          <div className="grid grid-cols-[1fr_6rem] gap-3">
            <Field label="Drink">
              <select value={drink} onChange={(e) => pick(e.target.value)} className={inputClass}>
                {DRINK_PRESETS.map((p) => (
                  <option key={p.drink} value={p.drink}>{p.drink}</option>
                ))}
              </select>
            </Field>
            <Field label="mg">
              <input type="number" min={1} max={1000} value={mg} onChange={(e) => setMg(e.target.value)} className={inputClass} required />
            </Field>
          </div>
          <button type="submit" className={ghostButton}>Add drink</button>
        </form>
        <div>
          <h3 className="mb-2 text-sm font-medium text-slate-300">Logged on {date}</h3>
          {error && <ErrorNote>{error}</ErrorNote>}
          {logs.length === 0 ? (
            <p className="text-sm text-slate-500">Nothing logged for this day.</p>
          ) : (
            <ul className="space-y-2">
              {logs.map((l) => (
                <li key={l.id} className="flex items-center justify-between rounded-lg bg-slate-900/50 px-3 py-2 text-sm">
                  <span>{formatClock12(l.time)} · {l.drink} · {l.mg} mg</span>
                  <button className="text-rose-300 hover:underline" onClick={() => void remove(l.id)} aria-label={`Delete ${l.drink} at ${l.time}`}>Delete</button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </Card>
  );
}
