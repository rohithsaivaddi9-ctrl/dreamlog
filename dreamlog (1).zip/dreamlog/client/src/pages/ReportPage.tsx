import { useEffect, useState } from 'react';
import type { ReportResponse } from '../../../shared/types';
import { formatDateShort } from '../../../shared/dates';
import { formatR } from '../../../shared/stats';
import { api } from '../lib/api';
import { ScatterChart } from '../components/ScatterChart';
import { ErrorNote, primaryButton } from '../components/ui';

const NAME_KEY = 'dreamlog.studentName';

function loadName(): string {
  try {
    return window.localStorage.getItem(NAME_KEY) ?? '';
  } catch {
    return '';
  }
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-lg border border-slate-200 p-3">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-900">{value}</p>
      {sub && <p className="text-xs text-slate-500">{sub}</p>}
    </div>
  );
}

export function ReportPage({ today }: { today: string }) {
  const [report, setReport] = useState<ReportResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [name, setName] = useState(loadName);

  useEffect(() => {
    api.report(today).then(setReport).catch((e: unknown) => setError(e instanceof Error ? e.message : 'Could not load report'));
  }, [today]);

  function changeName(value: string) {
    setName(value);
    try {
      window.localStorage.setItem(NAME_KEY, value);
    } catch {
      /* private mode: the name just isn't remembered */
    }
  }

  if (error) return <ErrorNote>{error}</ErrorNote>;
  if (!report) return <p className="text-sm text-slate-400">Loading report…</p>;

  const fmt = (v: number | null, digits = 1) => (v === null ? '–' : v.toFixed(digits));

  return (
    <div>
      <div className="mb-4 flex items-center justify-between print:hidden">
        <p className="text-sm text-slate-400">Print this page or choose "Save as PDF" in the print dialog to share it with an academic advisor.</p>
        <button className={primaryButton} onClick={() => window.print()}>Print / Save as PDF</button>
      </div>

      <article className="print-page rounded-2xl bg-white p-8 text-slate-800 shadow-xl">
        <header className="border-b border-slate-200 pb-4">
          <p className="text-xs font-semibold uppercase tracking-widest text-amber-600">DreamLog · Student Wellness Report</p>
          <h1 className="mt-1 text-2xl font-bold text-slate-900">Sleep and Academic Performance</h1>
          <div className="mt-3 flex flex-wrap items-end gap-x-8 gap-y-2 text-sm">
            <label className="flex items-center gap-2">
              <span className="text-slate-500">Student</span>
              <input
                value={name}
                onChange={(e) => changeName(e.target.value)}
                placeholder="Enter name"
                className="border-b border-slate-300 bg-transparent px-1 py-0.5 text-slate-900 outline-none placeholder:text-slate-400 focus:border-amber-500 print:border-none"
              />
            </label>
            <span><span className="text-slate-500">Period</span> {report.periodStart ? `${formatDateShort(report.periodStart)} – ${formatDateShort(report.periodEnd ?? report.periodStart)}` : '–'}</span>
            <span><span className="text-slate-500">Generated</span> {report.generatedOn}</span>
          </div>
        </header>

        <section className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3">
          <Metric label="Average sleep" value={`${fmt(report.avgSleep)} h`} sub={`Target ${report.sleepTarget} h`} />
          <Metric label="Last 7 nights" value={`${report.debt.shortfall.toFixed(1)} h short`} sub="Sleep debt vs target" />
          <Metric label="Average focus" value={`${fmt(report.avgFocus)} / 5`} />
          <Metric label="Average study" value={`${fmt(report.avgStudy)} h / day`} />
          <Metric label="Sleep-focus correlation" value={`r = ${formatR(report.correlation.r)}`} sub={report.correlation.label} />
          <Metric label="Days analysed" value={String(report.daysLogged)} sub={report.correlation.notice ?? 'Enough data for a stable estimate'} />
        </section>

        <section className="mt-6">
          <h2 className="mb-2 text-lg font-semibold text-slate-900">Sleep vs. study focus</h2>
          <ScatterChart pairs={report.pairs} regression={report.correlation.regression} latestDate={report.latest?.date ?? null} theme="light" height={300} />
        </section>

        <section className="mt-6 print:break-inside-avoid">
          <h2 className="mb-2 text-lg font-semibold text-slate-900">Exam and quiz performance</h2>
          {report.examScores.length === 0 ? (
            <p className="text-sm text-slate-500">No quiz or exam scores have been logged yet.</p>
          ) : (
            <>
              <table className="w-full text-left text-sm">
                <thead className="border-b border-slate-300 text-xs uppercase text-slate-500">
                  <tr><th className="py-1">Date</th><th>Subjects</th><th>Sleep before</th><th>Focus</th><th>Score</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {report.examScores.map((e) => (
                    <tr key={e.date}>
                      <td className="py-1">{formatDateShort(e.date)}</td>
                      <td>{e.subjects.join(', ')}</td>
                      <td>{e.sleepHours === null ? '–' : `${e.sleepHours} h`}</td>
                      <td>{e.focus}/5</td>
                      <td className="font-semibold">{e.score}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {report.examCorrelation && (
                <p className="mt-2 text-sm text-slate-700">
                  Across {report.examCorrelation.n} scored days, sleep duration and score show r = <strong>{formatR(report.examCorrelation.r)}</strong> ({report.examCorrelation.label.toLowerCase()}).
                  {report.examCorrelation.notice ? ` ${report.examCorrelation.notice}.` : ''}
                </p>
              )}
            </>
          )}
        </section>

        <section className="mt-6 print:break-inside-avoid">
          <h2 className="mb-2 text-lg font-semibold text-slate-900">Findings and recommendations</h2>
          <ul className="list-disc space-y-1 pl-5 text-sm text-slate-700">
            {report.insights.map((i) => <li key={i.id}>{i.text}</li>)}
            {report.insights.length === 0 && <li>Not enough logged days to draw conclusions yet.</li>}
          </ul>
        </section>

        <footer className="mt-8 border-t border-slate-200 pt-3 text-xs text-slate-500">
          Self-reported data from the student's DreamLog journal. Correlation describes a pattern in these logs and does not prove that sleep causes the differences in focus or scores. This report is not medical advice.
        </footer>
      </article>
    </div>
  );
}
