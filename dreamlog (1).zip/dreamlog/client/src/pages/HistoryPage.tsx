import { useCallback, useEffect, useState } from 'react';
import type { SleepLog, StudyLog } from '../../../shared/types';
import { formatDateShort } from '../../../shared/dates';
import { formatClock12 } from '../../../shared/time';
import { api } from '../lib/api';
import { Card, ErrorNote, ghostButton } from '../components/ui';

interface Row {
  date: string;
  sleep?: SleepLog;
  study?: StudyLog;
}

export function HistoryPage({ today, reload }: { today: string; reload: () => Promise<unknown> }) {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const [sleep, study] = await Promise.all([api.listSleep(), api.listStudy()]);
      const byDate = new Map<string, Row>();
      for (const s of sleep) byDate.set(s.date, { date: s.date, sleep: s });
      for (const s of study) byDate.set(s.date, { ...(byDate.get(s.date) ?? { date: s.date }), study: s });
      setRows([...byDate.values()].sort((a, b) => b.date.localeCompare(a.date)));
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load history');
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function remove(kind: 'sleep' | 'study', date: string) {
    if (!window.confirm(`Delete the ${kind} log for ${date}?`)) return;
    try {
      await (kind === 'sleep' ? api.deleteSleep(date) : api.deleteStudy(date));
      await Promise.all([load(), reload()]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not delete');
    }
  }

  async function resetDemo() {
    if (!window.confirm('Delete ALL logs and reload the 21-day demo data?')) return;
    try {
      await api.resetDemo(today);
      await Promise.all([load(), reload()]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not reset');
    }
  }

  return (
    <Card
      title="History"
      subtitle="Every logged day, newest first."
      action={<button className={ghostButton} onClick={() => void resetDemo()}>Reset to demo data</button>}
    >
      {error && <ErrorNote>{error}</ErrorNote>}
      {rows === null ? (
        <p className="text-sm text-slate-400">Loading…</p>
      ) : rows.length === 0 ? (
        <p className="text-sm text-slate-400">No logs yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="text-xs uppercase tracking-wide text-slate-400">
              <tr>
                <th className="py-2 pr-3">Date</th>
                <th className="pr-3">In bed → up</th>
                <th className="pr-3">Sleep</th>
                <th className="pr-3">Quality</th>
                <th className="pr-3">Studied</th>
                <th className="pr-3">Subjects</th>
                <th className="pr-3">Focus</th>
                <th className="pr-3">Score</th>
                <th />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {rows.map((r) => (
                <tr key={r.date} className="align-top">
                  <td className="py-2 pr-3 font-medium text-slate-100">{formatDateShort(r.date)}</td>
                  <td className="pr-3 text-slate-300">{r.sleep ? `${formatClock12(r.sleep.bedtime)} → ${formatClock12(r.sleep.wakeTime)}` : '–'}</td>
                  <td className="pr-3 text-slate-100">{r.sleep ? `${r.sleep.durationHours} h` : '–'}</td>
                  <td className="pr-3 text-amber-300">{r.sleep ? '★'.repeat(r.sleep.quality) : '–'}</td>
                  <td className="pr-3 text-slate-100">{r.study ? `${r.study.hoursStudied} h` : '–'}</td>
                  <td className="pr-3 text-slate-300">{r.study ? r.study.subjects.join(', ') : '–'}</td>
                  <td className="pr-3 text-slate-100">{r.study ? `${r.study.focus}/5` : '–'}</td>
                  <td className="pr-3 text-slate-100">{r.study?.score ?? '–'}</td>
                  <td className="space-x-3 whitespace-nowrap text-right">
                    {r.sleep && <button className="text-rose-300 hover:underline" onClick={() => void remove('sleep', r.date)}>Delete sleep</button>}
                    {r.study && <button className="text-rose-300 hover:underline" onClick={() => void remove('study', r.date)}>Delete study</button>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Card>
  );
}
