import type {
  AnalyticsResponse,
  CaffeineLog,
  CaffeineStatusResponse,
  ReportResponse,
  SleepLog,
  StudyLog,
} from '../../../shared/types';

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`/api${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...init,
    });
  } catch {
    throw new Error('Cannot reach the DreamLog server. Is it running? (npm run dev)');
  }
  const data: unknown = await res.json().catch(() => null);
  if (!res.ok) {
    const body = (data ?? {}) as { errors?: string[]; error?: string };
    throw new Error(body.errors?.join('. ') ?? body.error ?? `Request failed (${res.status})`);
  }
  return data as T;
}

const post = (body: unknown): RequestInit => ({ method: 'POST', body: JSON.stringify(body) });

export const api = {
  analytics: (today: string) => request<AnalyticsResponse>(`/analytics?today=${today}`),
  report: (today: string) => request<ReportResponse>(`/report?today=${today}`),

  listSleep: () => request<SleepLog[]>('/sleep'),
  saveSleep: (body: { date: string; bedtime: string; wakeTime: string; quality: number }) =>
    request<SleepLog>('/sleep', post(body)),
  deleteSleep: (date: string) => request<{ deleted: boolean }>(`/sleep/${date}`, { method: 'DELETE' }),

  listStudy: () => request<StudyLog[]>('/study'),
  saveStudy: (body: { date: string; hoursStudied: number; subjects: string[]; focus: number; score: number | null }) =>
    request<StudyLog>('/study', post(body)),
  deleteStudy: (date: string) => request<{ deleted: boolean }>(`/study/${date}`, { method: 'DELETE' }),

  listCaffeine: (date: string) => request<CaffeineLog[]>(`/caffeine?date=${date}`),
  addCaffeine: (body: { date: string; time: string; drink: string; mg: number }) =>
    request<CaffeineLog>('/caffeine', post(body)),
  deleteCaffeine: (id: number) => request<{ deleted: boolean }>(`/caffeine/${id}`, { method: 'DELETE' }),
  caffeineStatus: (date: string, bedtime: string) =>
    request<CaffeineStatusResponse>(`/caffeine/status?date=${date}&bedtime=${encodeURIComponent(bedtime)}`),

  saveSleepTarget: (sleepTarget: number) =>
    request<{ sleepTarget: number }>('/settings', { method: 'PUT', body: JSON.stringify({ sleepTarget }) }),
  resetDemo: (today: string) => request<{ ok: boolean }>('/demo/reset', post({ today })),
};
