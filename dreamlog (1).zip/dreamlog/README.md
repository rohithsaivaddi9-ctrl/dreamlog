# DreamLog: SnoozeScience Sprint

A sleep and study-productivity tracker for students. Log your nights and your study days, and DreamLog computes the correlation between how long you slept and how well you focused, plots it, and turns it into advice.

Built with **React + TypeScript + Chart.js + Tailwind CSS** (dark, night-friendly theme) on the front end and **Node.js + Express + SQLite** on the back end.

---

## Quick start (3 steps)

**You need:** [Node.js](https://nodejs.org) **version 22.13 or newer** (check with `node -v`). SQLite is built into Node 22, so there is nothing else to install.

1. Open a terminal in this folder and install everything:
   ```bash
   npm install
   ```
2. Start the app:
   ```bash
   npm run dev
   ```
3. Open **http://localhost:5173** in your browser.

On first start the database is created in `data/dreamlog.sqlite` and filled with **21 days of sample student data** (you'll see "Seeded 21 days of demo data" in the terminal). The sample days end *yesterday*, so today is free for the demo.

> Run it as one app instead (no hot reload): `npm run build`, then `npm start`, and open **http://localhost:3001**.

## The 60-second demo

1. Open the **Dashboard**. The 21 sample days show **r = +0.77 (Strong Positive Correlation)** and a scatter plot with a trendline.
2. Go to **Log** and press **Log demo night**. This saves last night (11:30 PM → 7:30 AM = **8.0 hours**, 4 stars) and today's study (**4.5 hours of Algorithms, focus 5/5**).
3. The Dashboard opens again: the correlation is now **r = +0.78**, the new point is highlighted on the scatter plot, and the card tells you how much the newest day moved r.

You can enter the same thing by hand with the two forms on the Log page. Want a clean slate? **History → Reset to demo data**.

## Features

| Feature | Where | Notes |
|---|---|---|
| Nightly sleep logger | Log | Bedtime, wake time, 1-5 stars. Duration is calculated automatically, including across midnight (11:30 PM → 7:30 AM = 8.0 h). |
| Study session tracker | Log | Hours, subjects, focus 1-5 (labelled, 5 = Deep Focus) and an optional quiz/exam score. |
| Correlation engine | Dashboard | Pearson r and R², a plain-English label, and the OLS trendline. Shows **"Needs at least 7 days of logs for statistical confidence"** until there are 7 days with both a sleep and a study log. |
| Scatter plot | Dashboard | Interactive Chart.js plot (hover for details), trendline, newest log highlighted. |
| Sleep debt | Dashboard | Hours short of your target over the last 7 nights (default 8 h, editable). |
| Weekly insights | Dashboard | Messages built from your own data, e.g. "Days following 7.5+ hours of sleep saw 68% higher study focus". |
| Optimal bedtime | Dashboard | Bedtimes that end on a 90-minute sleep-cycle boundary (plus ~15 min to fall asleep). |
| Caffeine tracker | Log + Dashboard | Log drinks; the chart shows caffeine still in your body (5-hour half-life) with bedtime marked. |
| Exam week sleep preserver | Exam week | Timetable with **at most 8 study hours/day** and **at least 7 hours of sleep**. Lighter days before and during exams. |
| Wellness report | Report | Printable one-page summary for an academic advisor (use **Print / Save as PDF**). Includes sleep vs. exam score. |
| History | History | Every day in a table, with delete. |

## How the key rules work

- **Sleep across midnight:** if the wake time is numerically earlier than the bedtime, 24 hours are added to the wake time before subtracting. `23:30 → 07:30` = 8.0 h; `00:30 → 07:00` = 6.5 h.
- **Which days count:** a sleep log is dated the morning you woke up and is paired with the study log for that same day. Only days with *both* are used for the correlation.
- **Sleep debt:** for the last 7 nights, each night below the target adds `target − hours` to the shortfall. Nights above target don't cancel it out. Nights with no log are shown as gaps and left out.
- **Pearson r:** `r = Σ(x−x̄)(y−ȳ) / √(Σ(x−x̄)² · Σ(y−ȳ)²)`, with x = hours slept and y = focus rating. The trendline is ordinary least squares.
- **Caffeine:** `remaining = dose × 0.5^(hours since drink ÷ 5)`. The drink amounts are typical averages and can be edited.

## Project layout

```
dreamlog/
├── client/                React app (Vite, Tailwind, Chart.js)
│   └── src/pages, components, lib
├── server/src/            Express API + SQLite
│   ├── app.ts             REST routes
│   ├── db.ts              schema (sleep_logs, study_logs, caffeine_logs, settings, correlation_metrics)
│   ├── repo.ts            database queries
│   ├── services.ts        analytics, caffeine status, report
│   └── seed.ts / seedData.ts   the 21-day demo dataset
├── shared/                pure logic used by both sides (stats, debt, insights, bedtime, caffeine, exam planner, validation)
└── tests/                 automated tests
```

## REST API

| Method & path | Purpose |
|---|---|
| `GET /api/analytics` | Correlation (r, trendline), sleep debt, insights, bedtime suggestions |
| `GET/POST /api/sleep`, `DELETE /api/sleep/:date` | Sleep logs (POST on an existing date updates it) |
| `GET/POST /api/study`, `DELETE /api/study/:date` | Study logs |
| `GET/POST /api/caffeine`, `DELETE /api/caffeine/:id` | Caffeine drinks (`?date=`) |
| `GET /api/caffeine/status?date=&bedtime=` | Decay curve and mg left at bedtime |
| `GET/PUT /api/settings` | Nightly sleep target |
| `GET /api/report` | Data for the wellness report |
| `POST /api/demo/reset` | Wipe logs and reload the 21-day demo data |

## Tests

```bash
npm test
```

Covers the midnight sleep calculation, the 8-hour sleep-debt target, Pearson/OLS maths, the 7-day confidence notice, the exam planner limits (study ≤ 8 h, sleep ≥ 7 h), bedtime and caffeine maths, input validation, and the demo numbers from the brief (r = +0.77 → +0.78). `npm run typecheck` checks the TypeScript.

## Troubleshooting

- **"node:sqlite" error / unsupported syntax:** your Node is too old. Install Node 22.13 or newer.
- **"ExperimentalWarning: SQLite is an experimental feature":** harmless. It's Node's built-in SQLite module.
- **Page says it can't reach the server:** use `npm run dev` (starts both the API on port 3001 and the web app on 5173), not just one of them. If 3001 is busy, run with `PORT=3002` and update the proxy in `client/vite.config.ts`.
- **Start over:** stop the app and delete the `data/` folder, or use History → Reset to demo data.
- The sample data is dated relative to the day it is first created. If you come back weeks later, use **Reset to demo data** to re-centre it on today.

## Notes

Correlation describes a pattern in your own logs; it doesn't prove that sleep causes better focus. Caffeine amounts and half-life are population averages and vary a lot between people. DreamLog is a study aid, not medical advice.
