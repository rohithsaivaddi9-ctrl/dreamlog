import path from 'node:path';
import { createApp } from './app';
import { openDb } from './db';
import { countSleep } from './repo';
import { seedDatabase } from './seed';
import { todayISO } from '../../shared/dates';

const PORT = Number(process.env.PORT ?? 3001);
const DB_PATH = process.env.DB_PATH ?? path.resolve(__dirname, '../../data/dreamlog.sqlite');
const CLIENT_DIR = path.resolve(__dirname, '../../dist/client');

const db = openDb(DB_PATH);
if (countSleep(db) === 0) {
  seedDatabase(db, todayISO());
  console.log('Seeded 21 days of demo data.');
}

createApp(db, CLIENT_DIR).listen(PORT, () => {
  console.log(`DreamLog API running on http://localhost:${PORT}`);
});
