import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export type Db = DatabaseSync;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS sleep_logs (
  date           TEXT PRIMARY KEY,           -- morning you woke up, YYYY-MM-DD
  bedtime        TEXT NOT NULL,              -- HH:MM
  wake_time      TEXT NOT NULL,              -- HH:MM
  duration_hours REAL NOT NULL,
  quality        INTEGER NOT NULL CHECK (quality BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS study_logs (
  date          TEXT PRIMARY KEY,
  hours_studied REAL NOT NULL CHECK (hours_studied >= 0),
  subjects      TEXT NOT NULL,               -- JSON array of strings
  focus         INTEGER NOT NULL CHECK (focus BETWEEN 1 AND 5),
  score         REAL                         -- optional quiz / exam score
);

CREATE TABLE IF NOT EXISTS caffeine_logs (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  date  TEXT NOT NULL,
  time  TEXT NOT NULL,
  drink TEXT NOT NULL,
  mg    REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- One row per day the correlation was recalculated (history of r over time).
CREATE TABLE IF NOT EXISTS correlation_metrics (
  computed_on TEXT PRIMARY KEY,
  n           INTEGER NOT NULL,
  r           REAL,
  slope       REAL,
  intercept   REAL,
  label       TEXT NOT NULL
);
`;

/** Opens (and creates, if needed) the SQLite database. Use ':memory:' for tests. */
export function openDb(file: string): Db {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec(SCHEMA);
  return db;
}
