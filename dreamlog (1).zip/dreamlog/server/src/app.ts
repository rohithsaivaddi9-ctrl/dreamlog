import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import type { Db } from './db';
import { todayISO, isValidISODate } from '../../shared/dates';
import { parseTime } from '../../shared/time';
import { validateCaffeineInput, validateSleepInput, validateSleepTarget, validateStudyInput } from '../../shared/validation';
import {
  addCaffeine,
  deleteCaffeine,
  deleteSleep,
  deleteStudy,
  getSleepTarget,
  listCaffeine,
  listSleep,
  listStudy,
  setSleepTarget,
  upsertSleep,
  upsertStudy,
} from './repo';
import { getAnalytics, getCaffeineStatus, getReport } from './services';
import { seedDatabase } from './seed';

type Handler = (req: Request, res: Response) => void;

/** Express 4 does not catch errors thrown in handlers by itself, so wrap them. */
const safe =
  (fn: Handler) =>
  (req: Request, res: Response, next: NextFunction): void => {
    try {
      fn(req, res);
    } catch (err) {
      next(err);
    }
  };

export function createApp(db: Db, clientDir?: string): express.Express {
  const app = express();
  app.use(express.json());

  // ---- sleep ----
  app.get('/api/sleep', safe((_req, res) => void res.json(listSleep(db))));
  app.post(
    '/api/sleep',
    safe((req, res) => {
      const v = validateSleepInput(req.body);
      if (!v.ok) return void res.status(400).json({ errors: v.errors });
      res.status(201).json(upsertSleep(db, v.value));
    }),
  );
  app.delete(
    '/api/sleep/:date',
    safe((req, res) => {
      const ok = isValidISODate(req.params.date) && deleteSleep(db, req.params.date);
      res.status(ok ? 200 : 404).json({ deleted: ok });
    }),
  );

  // ---- study ----
  app.get('/api/study', safe((_req, res) => void res.json(listStudy(db))));
  app.post(
    '/api/study',
    safe((req, res) => {
      const v = validateStudyInput(req.body);
      if (!v.ok) return void res.status(400).json({ errors: v.errors });
      res.status(201).json(upsertStudy(db, v.value));
    }),
  );
  app.delete(
    '/api/study/:date',
    safe((req, res) => {
      const ok = isValidISODate(req.params.date) && deleteStudy(db, req.params.date);
      res.status(ok ? 200 : 404).json({ deleted: ok });
    }),
  );

  // ---- caffeine ----
  app.get(
    '/api/caffeine',
    safe((req, res) => {
      const date = typeof req.query.date === 'string' ? req.query.date : undefined;
      if (date !== undefined && !isValidISODate(date)) return void res.status(400).json({ errors: ['date must be YYYY-MM-DD'] });
      res.json(listCaffeine(db, date));
    }),
  );
  app.post(
    '/api/caffeine',
    safe((req, res) => {
      const v = validateCaffeineInput(req.body);
      if (!v.ok) return void res.status(400).json({ errors: v.errors });
      res.status(201).json(addCaffeine(db, v.value));
    }),
  );
  app.delete(
    '/api/caffeine/:id',
    safe((req, res) => {
      const id = Number(req.params.id);
      const ok = Number.isInteger(id) && deleteCaffeine(db, id);
      res.status(ok ? 200 : 404).json({ deleted: ok });
    }),
  );
  app.get(
    '/api/caffeine/status',
    safe((req, res) => {
      const date = typeof req.query.date === 'string' ? req.query.date : todayISO();
      const bedtime = typeof req.query.bedtime === 'string' ? req.query.bedtime : '23:30';
      if (!isValidISODate(date) || parseTime(bedtime) === null) {
        return void res.status(400).json({ errors: ['date must be YYYY-MM-DD and bedtime HH:MM'] });
      }
      res.json(getCaffeineStatus(db, date, bedtime));
    }),
  );

  // ---- analytics, settings, report ----
  app.get('/api/analytics', safe((req, res) => {
    const today = typeof req.query.today === 'string' && isValidISODate(req.query.today) ? req.query.today : todayISO();
    res.json(getAnalytics(db, today));
  }));
  app.get('/api/report', safe((req, res) => {
    const today = typeof req.query.today === 'string' && isValidISODate(req.query.today) ? req.query.today : todayISO();
    res.json(getReport(db, today));
  }));
  app.get('/api/settings', safe((_req, res) => void res.json({ sleepTarget: getSleepTarget(db) })));
  app.put(
    '/api/settings',
    safe((req, res) => {
      const v = validateSleepTarget(req.body);
      if (!v.ok) return void res.status(400).json({ errors: v.errors });
      setSleepTarget(db, v.value);
      res.json({ sleepTarget: v.value });
    }),
  );

  /** Wipes all logs and reloads the 21-day demo dataset ending yesterday. */
  app.post('/api/demo/reset', safe((req, res) => {
    const today = typeof req.body?.today === 'string' && isValidISODate(req.body.today) ? req.body.today : todayISO();
    seedDatabase(db, today, true);
    res.json({ ok: true });
  }));

  app.use('/api', (_req, res) => void res.status(404).json({ error: 'Not found' }));

  // ---- built client (after `npm run build`) ----
  if (clientDir && fs.existsSync(path.join(clientDir, 'index.html'))) {
    app.use(express.static(clientDir));
    app.get('*', (_req, res) => void res.sendFile(path.join(clientDir, 'index.html')));
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong on the server' });
  });

  return app;
}
