import type { Db } from './db';
import type {
  AnalyticsResponse,
  CaffeineStatusResponse,
  ExamScoreRow,
  Pair,
  ReportResponse,
  SleepLog,
  StudyLog,
} from '../../shared/types';
import { recommendBedtimes } from '../../shared/bedtime';
import { bedtimeHour, caffeineCurve, caffeineMessage, caffeineLevel, caffeineRemaining } from '../../shared/caffeine';
import { computeSleepDebt } from '../../shared/debt';
import { generateInsights } from '../../shared/insights';
import { analyzeCorrelation, correlationWithChange, mean } from '../../shared/stats';
import { averageTime } from '../../shared/time';
import {
  getSleepTarget,
  listCaffeine,
  listSleep,
  listStudy,
  saveCorrelationMetrics,
} from './repo';

/** Days that have both a sleep log and a study log, oldest first. */
export function buildPairs(sleep: SleepLog[], study: StudyLog[]): Pair[] {
  const sleepByDate = new Map(sleep.map((s) => [s.date, s]));
  const pairs: Pair[] = [];
  for (const st of study) {
    const sl = sleepByDate.get(st.date);
    if (!sl) continue;
    pairs.push({
      date: st.date,
      sleepHours: sl.durationHours,
      focus: st.focus,
      quality: sl.quality,
      hoursStudied: st.hoursStudied,
      score: st.score,
    });
  }
  return pairs.sort((a, b) => a.date.localeCompare(b.date));
}

export function getAnalytics(db: Db, today: string): AnalyticsResponse {
  const sleep = listSleep(db);
  const study = listStudy(db);
  const sleepTarget = getSleepTarget(db);
  const pairs = buildPairs(sleep, study);
  const { current, previous, latest } = correlationWithChange(pairs);
  const debt = computeSleepDebt(sleep, sleepTarget, 7);
  const insights = generateInsights(pairs, debt);

  saveCorrelationMetrics(db, today, current);

  const recentWakes = sleep.slice(-7).map((s) => s.wakeTime);
  const suggestedWake = averageTime(recentWakes) ?? '07:00';
  return {
    today,
    sleepTarget,
    pairs,
    current,
    previous,
    latest,
    debt,
    insights,
    bedtime: { suggestedWake, options: recommendBedtimes(suggestedWake, sleepTarget) },
  };
}

export function getCaffeineStatus(db: Db, date: string, bedtime: string): CaffeineStatusResponse {
  const doses = listCaffeine(db, date);
  const bedHour = bedtimeHour(bedtime);
  const mgAtBedtime = caffeineRemaining(doses, bedHour);
  return {
    date,
    bedtime,
    doses,
    curve: caffeineCurve(doses),
    bedtimeHour: bedHour,
    mgAtBedtime: Math.round(mgAtBedtime * 10) / 10,
    level: caffeineLevel(mgAtBedtime),
    message: caffeineMessage(mgAtBedtime),
  };
}

export function getReport(db: Db, today: string): ReportResponse {
  const sleep = listSleep(db);
  const study = listStudy(db);
  const sleepTarget = getSleepTarget(db);
  const pairs = buildPairs(sleep, study);
  const { current, latest } = correlationWithChange(pairs);
  const debt = computeSleepDebt(sleep, sleepTarget, 7);

  const dates = [...sleep.map((s) => s.date), ...study.map((s) => s.date)].sort();
  const sleepByDate = new Map(sleep.map((s) => [s.date, s]));
  const examScores: ExamScoreRow[] = study
    .filter((s): s is StudyLog & { score: number } => s.score !== null)
    .map((s) => ({
      date: s.date,
      subjects: s.subjects,
      score: s.score,
      sleepHours: sleepByDate.get(s.date)?.durationHours ?? null,
      focus: s.focus,
    }));
  const scored = examScores.filter((e): e is ExamScoreRow & { sleepHours: number } => e.sleepHours !== null);
  const examCorrelation =
    scored.length >= 3
      ? analyzeCorrelation(
          scored.map((e) => e.sleepHours),
          scored.map((e) => e.score),
        )
      : null;

  return {
    generatedOn: today,
    periodStart: dates[0] ?? null,
    periodEnd: dates[dates.length - 1] ?? null,
    daysLogged: pairs.length,
    avgSleep: sleep.length ? mean(sleep.map((s) => s.durationHours)) : null,
    avgFocus: study.length ? mean(study.map((s) => s.focus)) : null,
    avgStudy: study.length ? mean(study.map((s) => s.hoursStudied)) : null,
    sleepTarget,
    debt,
    correlation: current,
    pairs,
    latest,
    examScores,
    examCorrelation,
    insights: generateInsights(pairs, debt),
  };
}
