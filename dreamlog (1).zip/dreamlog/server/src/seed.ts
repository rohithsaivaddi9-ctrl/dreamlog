import type { Db } from './db';
import { addDays } from '../../shared/dates';
import { sleepDurationHours } from '../../shared/time';
import { SEED_DAYS } from './seedData';
import { addCaffeine, clearLogs, upsertSleep, upsertStudy } from './repo';

/**
 * Fills the database with 21 days of realistic logs ending yesterday, so that today is free
 * for the demo night. Existing logs are NOT touched unless `replace` is true.
 */
export function seedDatabase(db: Db, today: string, replace = false): void {
  if (replace) clearLogs(db);
  for (const d of SEED_DAYS) {
    const date = addDays(today, -d.daysAgo);
    upsertSleep(db, {
      date,
      bedtime: d.bedtime,
      wakeTime: d.wakeTime,
      quality: d.quality,
      durationHours: sleepDurationHours(d.bedtime, d.wakeTime),
    });
    upsertStudy(db, {
      date,
      hoursStudied: d.hoursStudied,
      subjects: d.subjects,
      focus: d.focus,
      score: d.score,
    });
  }
  // A few coffees on recent days so the caffeine overlay has something to show.
  const yesterday = addDays(today, -1);
  addCaffeine(db, { date: yesterday, time: '08:30', drink: 'Brewed coffee (cup)', mg: 95 });
  addCaffeine(db, { date: yesterday, time: '15:00', drink: 'Espresso (shot)', mg: 63 });
  addCaffeine(db, { date: yesterday, time: '20:30', drink: 'Energy drink (can)', mg: 80 });
}
