// Clock-time helpers. Times are "HH:MM" strings in 24 h format.

const DAY_MINUTES = 24 * 60;

/** "HH:MM" -> minutes since midnight, or null if the text is not a valid time. */
export function parseTime(t: unknown): number | null {
  if (typeof t !== 'string') return null;
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(t);
  if (!m) return null;
  return Number(m[1]) * 60 + Number(m[2]);
}

/** Minutes since midnight -> "HH:MM" (wraps around midnight both ways). */
export function formatTime(minutes: number): string {
  const wrapped = ((Math.round(minutes) % DAY_MINUTES) + DAY_MINUTES) % DAY_MINUTES;
  const h = Math.floor(wrapped / 60);
  const m = wrapped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/** "23:30" -> "11:30 PM" */
export function formatClock12(t: string): string {
  const mins = parseTime(t);
  if (mins === null) return t;
  const h24 = Math.floor(mins / 60);
  const m = mins % 60;
  const suffix = h24 >= 12 ? 'PM' : 'AM';
  const h12 = h24 % 12 === 0 ? 12 : h24 % 12;
  return `${h12}:${String(m).padStart(2, '0')} ${suffix}`;
}

/**
 * Hours slept between a bedtime and the next wake time.
 * If the wake time is numerically earlier than the bedtime (11:30 PM -> 7:30 AM) the
 * wake time is on the next day, so 24 hours are added before subtracting.
 * Same bedtime and wake time gives 0 (the form rejects it as invalid).
 */
export function sleepDurationHours(bedtime: string, wakeTime: string): number {
  const bed = parseTime(bedtime);
  const wake = parseTime(wakeTime);
  if (bed === null || wake === null) {
    throw new Error('Bedtime and wake time must be in HH:MM format');
  }
  let diff = wake - bed;
  if (diff < 0) diff += DAY_MINUTES;
  return Math.round((diff / 60) * 100) / 100;
}

/** Average of several "HH:MM" times (fine for times that sit close together, like wake-ups). */
export function averageTime(times: string[]): string | null {
  const mins = times.map(parseTime).filter((v): v is number => v !== null);
  if (mins.length === 0) return null;
  return formatTime(mins.reduce((a, b) => a + b, 0) / mins.length);
}
