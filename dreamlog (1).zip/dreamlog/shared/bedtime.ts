import { formatTime, parseTime } from './time';
import type { BedtimeOption } from './types';

export const CYCLE_MINUTES = 90;
/** Typical time to fall asleep; added so you are asleep when the first cycle starts. */
export const FALL_ASLEEP_MINUTES = 15;

/**
 * Bedtimes that let you wake up at the end of a 90-minute sleep cycle
 * (4, 5 or 6 cycles = 6, 7.5 or 9 hours), which avoids waking from deep sleep.
 * The recommended option is the one closest to the sleep target (ties go to more sleep).
 */
export function recommendBedtimes(wakeTime: string, targetHours = 8): BedtimeOption[] {
  const wake = parseTime(wakeTime);
  if (wake === null) throw new Error('Wake time must be in HH:MM format');
  const cycleCounts = [6, 5, 4];
  let best = cycleCounts[0];
  for (const c of cycleCounts) {
    const diff = Math.abs((c * CYCLE_MINUTES) / 60 - targetHours);
    const bestDiff = Math.abs((best * CYCLE_MINUTES) / 60 - targetHours);
    if (diff < bestDiff || (diff === bestDiff && c > best)) best = c;
  }
  return cycleCounts.map((cycles) => ({
    cycles,
    sleepHours: (cycles * CYCLE_MINUTES) / 60,
    bedtime: formatTime(wake - cycles * CYCLE_MINUTES - FALL_ASLEEP_MINUTES),
    recommended: cycles === best,
  }));
}
